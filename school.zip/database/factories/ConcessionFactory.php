<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Concession;
use Faker\Generator as Faker;

$factory->define(Concession::class, function (Faker $faker) {
    return [
        //
    ];
});
