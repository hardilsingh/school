<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Stream;
use Faker\Generator as Faker;

$factory->define(Stream::class, function (Faker $faker) {
    return [
        //
    ];
});
