<?php

namespace App\Http\Controllers;

use App\Grade;
use App\Students;
use Illuminate\Http\Request;
use Excel;


use App\Exports\StudentsExport;

class PrintController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $classes = Grade::pluck('class', 'id');
        return view('admin.prints.index', compact(['classes']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\StudentsController  $studentsController
     * @return \Illuminate\Http\Response
     */
    public function show(StudentsController $studentsController)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\StudentsController  $studentsController
     * @return \Illuminate\Http\Response
     */
    public function edit(StudentsController $studentsController)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\StudentsController  $studentsController
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, StudentsController $studentsController)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\StudentsController  $studentsController
     * @return \Illuminate\Http\Response
     */
    public function destroy(StudentsController $studentsController)
    {
        //
    }

    public function prints()
    {
        if (isset($_GET['classId'])) {
            $section = $_GET['sectionId'];
            $class = $_GET['classId'];

            $students = Students::where('class', $class)->where('section', $section)->get();
            return view('admin.prints.print', compact(["students", "section", 'class']));
        }
    }


    public function export()
    {
        return Excel::download(new StudentsExport, 'student.xlsx');
    }

    public function pdf()
    {
        return (new StudentsExport)->donload('invoices.pdf', \Maatwebsite\Excel\Excel::DOMPDF);
    }
}
