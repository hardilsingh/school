<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use App\Students;

class StudentsExport implements FromView
{
    public function view(): View
    {

        if (isset($_GET['classId'])) {
            $section = $_GET['sectionId'];
            $class = $_GET['classId'];

            return view('admin.exports.classWise', [
                'students' => Students::where('class', $class)->where('section', $section)->get(),
                'class'=>$class,
                'section'=>$section
            ]);
        }
    }
}
