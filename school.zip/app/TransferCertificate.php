<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransferCertificate extends Model
{
    //
}
